use battle_game;
/*
	Create users to the database
*/
CREATE USER 'admin'@'localhost' IDENTIFIED BY 'admin';
GRANT ALL PRIVILEGES ON battle_game.* TO 'admin'@'localhost';

CREATE USER 'free-user'@'localhost' IDENTIFIED BY 'free-user';
CREATE USER 'primium-user'@'localhost' IDENTIFIED BY 'primium-user';
GRANT SELECT, UPDATE, INSERT, DELETE ON battle_game.player_character TO 'free-user'@'localhost', 'primium-user'@'localhost';
GRANT SELECT, INSERT, DELETE ON battle_game.player_inventory TO 'free-user'@'localhost','primium-user'@'localhost';
GRANT SELECT, DELETE ON battle_game.player_skill TO 'free-user'@'localhost', 'primium-user'@'localhost' ;
GRANT SELECT, UPDATE ON battle_game.stats TO 'free-user'@'localhost', 'primium-user'@'localhost';

GRANT SELECT ON battle_game.statistics TO 'primium-user'@'localhost';
GRANT SELECT ON battle_game.leaderboard TO 'primium-user'@'localhost';
GRANT SELECT ON battle_game.game_event TO 'primium-user'@'localhost';

SHOW GRANTS FOR 'admin'@'localhost';
SHOW GRANTS FOR 'free-user'@'localhost';
SHOW GRANTS FOR 'primium-user'@'localhost';

/*
reset users
drop user 'admin'@'localhost';
drop user 'free-user'@'localhost';
drop user 'primium-user'@'localhost';
*/
