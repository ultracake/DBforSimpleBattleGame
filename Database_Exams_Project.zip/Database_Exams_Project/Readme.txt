This project is a database for a game called "Battle game"
and demo console application for transaction.
The console application is written in c#.

the database script: 

- battle_game.sql : setup for the database and tables.
- battle_game_populate.sql: populates the tables.    
- battle_game_functions.sql: demonstrates the requirements for the assignment (views, indexes, temporary tables, stored procedures and functions, scheduled events, and transactions).
- battle_game_trigger.sql: demonstrates a trigger for player_skill.
- battle_game_user.sql: user setup. 

