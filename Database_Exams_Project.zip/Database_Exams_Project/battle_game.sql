
drop database if exists battle_game;
create database if not exists battle_game;
use battle_game;

create table user_account (
username varchar(50) primary key,
user_password varchar(50) not null,
priviledge varchar(50) not null default "free-user"
) ENGINE=InnoDB;

create table player_character (
user_account_id varchar(50),
id int auto_increment primary key,
nickname varchar(40),
max_health int not null default 1,
current_health int not null default 1,
max_mana int not null default 1,
current_mana int not null default 1,
attack int not null default 1,
defence int not null default 1,
player_level int not null default 0,
foreign key (user_account_id) references user_account(username)
on delete cascade on update cascade
) ENGINE=InnoDB;

create table stats (
id int auto_increment primary key,
player_id int,
kills int not null default 0,
heals int not null default 0,
damage int not null default 0,
foreign key (player_id) references player_character(id)
on delete cascade on update cascade
) ENGINE=InnoDB;

create table item(
    id int auto_increment primary key,
    item_name varchar(20) not null,
    item_description varchar(150) not null,
    defense int not null default 0,
    damage int not null default 0,
    health int not null default 0,
    mana int not null default 0
) ENGINE=InnoDB;

create table shop(
    id int auto_increment primary key,
    x_coord int not null,
    y_coord int not null
) ENGINE=InnoDB;

create table shop_inventory(
    item_id int,
    shop_id int,
    foreign key (item_id) references item(id) 
    on delete cascade on update cascade,
    foreign key (shop_id) references shop(id)
    on delete cascade on update cascade,
    primary key (item_id, shop_id)
) ENGINE=InnoDB;

create table player_inventory(
    item_id int,
    player_id int,
    foreign key (item_id) references item(id) 
    on delete cascade on update cascade,
    foreign key (player_id) references player_character(id)
    on delete cascade on update cascade,
    primary key (item_id, player_id)
) ENGINE=InnoDB;

/*
"Indexes" are used to retrieve data from the database more quickly than otherwise. 
The users cannot see the indexes, they are just used to speed up searches/queries.
*/

create table skill(
    id int auto_increment primary key,
    skill_name varchar(20) not null,
    skill_description varchar(150) not null,
    health_modifier float not null default 1,
    damage_modifier float not null default 1,
    level_req int not null,
    INDEX (level_req)
) ENGINE=InnoDB;

create table player_skill (
player_id int,
skill_id int,
primary key(player_id, skill_id),
foreign key (player_id) references player_character(id)
on delete cascade on update cascade,
foreign key (skill_id) references skill(id) 
on delete cascade on update cascade
) ENGINE=InnoDB;

create table enemy (
id int auto_increment primary key,
nickname varchar(40) not null,
max_health int not null default 1,
damage int not null default 1, 
enemy_description varchar(64) not null
) ENGINE=InnoDB;

create table enemy_skill (
enemy_id int,
skill_id int,
primary key(enemy_id, skill_id),
foreign key (enemy_id) references enemy(id) 
on delete cascade on update cascade,
foreign key (skill_id) references skill(id) 
on delete cascade on update cascade
) ENGINE=InnoDB;

create table game_event (
id int auto_increment primary key,
enemy_id int,
modifier_multiplier float not null default 1,
event_name varchar(40) not null,
event_date datetime not null,
event_description varchar(64) not null,
foreign key (enemy_id) references enemy(id) 
on delete cascade on update cascade
) ENGINE=InnoDB;

CREATE VIEW leaderboard AS
SELECT  player.nickname, s.kills, s.heals, s.damage
FROM stats as s
join player_character as player
WHERE s.player_id = player.id 
order by s.kills desc
limit 10 ;

create view statistics as
SELECT avg(kills), sum(kills), sum(heals), sum(damage), player.user_account_id from stats
join player_character as player on player.id = stats.player_id 
group by player.user_account_id;


