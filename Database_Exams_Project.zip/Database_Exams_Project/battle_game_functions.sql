use battle_game;

/* create a player and check leaderboard (view)*/
insert into player_character (user_account_id, nickname, max_health, current_health, max_mana, current_mana, attack, defence, player_level)
values("Gamer24/7", "hamster33", 500, 500, 200, 200, 30, 50, 7);

insert into stats (player_id, kills, heals, damage) values 
((select id from player_character where nickname = "hamster33"), 550, 10, 500);

SELECT * FROM battle_game.leaderboard;

SELECT * FROM statistics;

/* create a temporary tables for player_character and player_inventory (Temporary tables)*/
drop temporary table if exists temp_player_character;
CREATE TEMPORARY TABLE temp_player_character SELECT * FROM player_character;
select * from temp_player_character;

drop temporary table if exists temp_player_inventory;
CREATE TEMPORARY TABLE temp_player_inventory SELECT * FROM player_inventory;
select * from temp_player_inventory;


/*functions and temporary table*/
drop temporary table if exists temp_user_stats;
CREATE TEMPORARY TABLE temp_user_stats 
SELECT avg(kills), sum(kills), sum(heals), sum(damage), player.user_account_id from stats
join player_character as player on player.id = stats.player_id 
group by player.user_account_id;
 
select * from temp_user_stats;


/* scheduled events*/
drop event if exists up_comming_event;
create event up_comming_event
    ON SCHEDULE AT CURRENT_TIMESTAMP + INTERVAL 1 HOUR
    ON COMPLETION NOT PRESERVE
    COMMENT 'allow special monsters'
    DO insert into game_event (enemy_id, modifier_multiplier, event_name, event_date, event_description) 
    values ((select id from enemy where nickname = "Giga Wolf"),
			2.5, "Hardcore", "2020-06-03 04:00:00",
            "The hardest challenge with the biggest reward2");
            
show events;
 