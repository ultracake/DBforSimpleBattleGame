use battle_game;

insert into user_account values("Gamer24/7", "kode1", "free-user"), 
	("Big_G", "123kode", "primium-user"),
	("Gamer-god", "kode22", "primium-user");
                               
insert into player_character (user_account_id, nickname, max_health, current_health, max_mana, current_mana, attack, defence, player_level)
values("Gamer24/7", "Rat_slayer", 500, 500, 200, 200, 30, 50, 0),
	("Gamer24/7", "Clever_Jack", 800, 800, 800, 800, 10, 10, 0),
    ("Gamer24/7", "Mega DPS", 120, 120, 50, 50, 250, 50, 0),
    ("Gamer24/7", "Jumboburger", 600, 600, 200, 200, 20, 50, 0),
    ("Big_G", "Jumboburger36", 630, 630, 250, 250, 20, 50, 0),
    ("Big_G", "cake eater", 270, 270, 550, 550, 70, 50, 0),
	("Big_G", "friendship power2000", 1000, 900, 550, 300, 20, 80, 0),
	("Big_G", "Legend27", 50, 50, 500, 350, 80, 10, 0),
	("Gamer-god", "grill master", 700, 600, 200, 100, 50, 30, 0),
	("Gamer-god", "Rat_slayer2", 600, 600, 100, 100, 70, 10, 0),
    ("Gamer-god", "Bat_beast99", 400, 400, 200, 200, 50, 30, 0);
                   
insert into stats (player_id, kills, heals, damage) 
values ((select id from player_character where nickname = "Rat_Slayer"), 50, 10, 500),
	((select id from player_character where nickname = "Rat_Slayer"), 60, 20, 700),
    ((select id from player_character where nickname = "Rat_Slayer"), 10, 0, 300),
    ((select id from player_character where nickname = "Rat_Slayer"), 75, 50, 770),
    ((select id from player_character where nickname = "Legend27"), 100, 20, 1070),
	((select id from player_character where nickname = "Legend27"), 500, 10, 5070),
	((select id from player_character where nickname = "Legend27"), 200, 30, 3070),
	((select id from player_character where nickname = "Legend27"), 100, 20, 1070),
    ((select id from player_character where nickname = "grill master"), 300, 80, 2070),
	((select id from player_character where nickname = "grill master"), 330, 56, 2170),
	((select id from player_character where nickname = "grill master"), 333, 50, 2370),
	((select id from player_character where nickname = "grill master"), 202, 40, 1250);
                                   
insert into item (item_name, item_description, defense, damage, health, mana) values
	("longsword", "stab fools with this", 0, 10, 0, 0),
	("shortsword", "stab short fools with this", 0, 5, 0, 0),
	("2h sword", "stab big fools with this", 0, 20, 0, 0),
	("breastplate", "dont get stabbed as hard", 15, 0, 5, 0),
	("magic helm", "dont get magically stabbed", 5, 0, 5, 5),
	("wooden stick", "stab weak fools", 0, 1, 1, 0),
	("long bow", "Stab from a good range", 0, 20, 0, 0),
	("short bow", "Stab from a medium range", 0, 10, 0, 0),
	("wand", "magically stab fools", 0, 10, 0, 20),
	("wand of fortitude", "magically stab fools with health", 0, 10, 10, 20),
	("skateboard", "get away from fools trying to stab you", 0, 0, 10, 5),
	("boots", "get away from fools trying to stab you with protection", 5, 0, 10, 5),
	("mana cricket", "Can't stab anything with this fool", 0, 0, 0, 30);
    
    
insert into shop (x_coord, y_coord) values
	(1,1),
    (1,2);
    
insert into shop_inventory (item_id, shop_id) values
	((select id from item where item_name = "longsword"), (select id from shop where x_coord = 1 and y_coord = 1)),
	((select id from item where item_name = "shortsword"), (select id from shop where x_coord = 1 and y_coord = 1)),
	((select id from item where item_name = "2h sword"), (select id from shop where x_coord = 1 and y_coord = 1)),
	((select id from item where item_name = "wooden stick"), (select id from shop where x_coord = 1 and y_coord = 1)),
	((select id from item where item_name = "magic helm"), (select id from shop where x_coord = 1 and y_coord = 2)),
	((select id from item where item_name = "breastplate"), (select id from shop where x_coord = 1 and y_coord = 2)),
	((select id from item where item_name = "long bow"), (select id from shop where x_coord = 1 and y_coord = 2)),
	((select id from item where item_name = "wand"), (select id from shop where x_coord = 1 and y_coord = 2)),
	((select id from item where item_name = "boots"), (select id from shop where x_coord = 1 and y_coord = 2));
    
insert into player_inventory (item_id, player_id) values
	((select id from item where item_name = "boots"), (select id from player_character where nickname = "Rat_Slayer")),
	((select id from item where item_name = "breastplate"), (select id from player_character where nickname = "Rat_Slayer")),
	((select id from item where item_name = "magic helm"), (select id from player_character where nickname = "Rat_Slayer")),
	((select id from item where item_name = "wand of fortitude"), (select id from player_character where nickname = "Rat_Slayer")),
	((select id from item where item_name = "skateboard"), (select id from player_character where nickname = "Clever_Jack")),
	((select id from item where item_name = "long bow"), (select id from player_character where nickname = "Clever_Jack")),
	((select id from item where item_name = "wand"), (select id from player_character where nickname = "Mega DPS")),
	((select id from item where item_name = "mana cricket"), (select id from player_character where nickname = "Mega DPS")),
	((select id from item where item_name = "boots"), (select id from player_character where nickname = "Mega DPS")),
	((select id from item where item_name = "wooden stick"), (select id from player_character where nickname = "Jumboburger")),
	((select id from item where item_name = "magic helm"), (select id from player_character where nickname = "Jumboburger")),
	((select id from item where item_name = "shortsword"), (select id from player_character where nickname = "Jumboburger36")),
	((select id from item where item_name = "shortsword"), (select id from player_character where nickname = "Rat_Slayer2")),
	((select id from item where item_name = "boots"), (select id from player_character where nickname = "Rat_Slayer2")),
	((select id from item where item_name = "shortsword"), (select id from player_character where nickname = "Bat_beast99")),
	((select id from item where item_name = "skateboard"), (select id from player_character where nickname = "Bat_beast99")),
	((select id from item where item_name = "breastplate"), (select id from player_character where nickname = "Bat_beast99")),
	((select id from item where item_name = "longsword"), (select id from player_character where nickname = "cake eater"));
    
    
insert into skill (skill_name, skill_description, health_modifier, damage_modifier, level_req) values
	("scratch", "When you want to stab without the puncturing part", 1, 1.2, 0),
    ("bite", "When you want to stab but you're a bit hungry too", 1, 1.5, 1),
    ("shield bash", "rich guy over here with his shield", 1.5, 1.8, 2),
    ("lightning strike", "stab fools with the power of electricity and no stab holes", 1, 3.5, 3),
	("tackle", "For not so smart characters that have no way to stab", 1, 1.4, 4),
    ("increase health", "A very creative skill unlike anything ever seen", 1.2, 1, 5),
    ("decrease health", "A very creative skill unlike anything ever seen but against an enemy", 0.5, 1, 6),
    ("decrease damage", "A very creative skill unlike anything ever seen but with damage against an enemy", 1, 0.5, 7),
    ("fireball", "when you're tired of stabbing fools so you throw fire", 1, 2.0, 8),
    ("ice shield", "cant get stabbed through this mofo", 5.0, 0.1, 9),
    ("increase damage", "A very creative skill unlike anything ever seen but with damage", 1.2, 1, 10);
    

insert into enemy (nickname, max_health, damage, enemy_description) values ("Rat", 50, 25, "Why do all games have rats that you need to kill?"), 
("Dog", 75, 40, "Smaller than a wolf"), 
("Wolf", 100, 50, "Bigger than a dog"),
("Cat", 40, 20, "Somehow less scary than a rat");

insert into player_skill (skill_id, player_id) values
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "Rat_Slayer")),
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "friendship power2000")),
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "Clever_Jack")),
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "Mega DPS")),
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "Jumboburger")),
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "Legend27")),
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "Jumboburger36")),
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "grill master")),
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "Rat_Slayer2")),
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "Bat_beast99")),
    ((select id from skill where skill_name = "scratch"), (select id from player_character where nickname = "cake eater"));
    
insert into enemy_skill (skill_id, enemy_id) values
    ((select id from skill where skill_name = "scratch"), (select id from enemy where nickname = "Rat")),
    ((select id from skill where skill_name = "bite"), (select id from enemy where nickname = "Dog")),
    ((select id from skill where skill_name = "tackle"), (select id from enemy where nickname = "Wolf")),
    ((select id from skill where skill_name = "bite"), (select id from enemy where nickname = "Wolf")),
    ((select id from skill where skill_name = "scratch"), (select id from enemy where nickname = "Cat")),
    ((select id from skill where skill_name = "bite"), (select id from enemy where nickname = "Cat"));
    
insert into game_event (enemy_id, modifier_multiplier, event_name, event_date, event_description) values ((select id from enemy where nickname = "Rat"), 1.5, "RATS", "2020-06-03 16:00:00", "You fight an increased amount of rats with bonus rewards"),
((select id from enemy where nickname = "Wolf"), 2.5, "Hardcore", "2020-06-03 04:00:00", "The hardest challenge with the biggest reward");
    