﻿using System;
using MySql.Data.MySqlClient;

namespace TransactionDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            string connectionString = "server=localhost;database=battle_game;uid=root;pwd=;";
            MySqlConnection cnn;
            cnn = new MySqlConnection(connectionString);


            using (cnn = new MySqlConnection(connectionString))
            {
                try
                {
                    //Open connection
                    cnn.Open();
                    Console.WriteLine("Connection Open ! ");

                    Console.WriteLine("Executing successful transaction");
                    //In here we execute our sql commands
                    ExecuteSqlCommands(cnn);

                    cnn.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Can not open connection! Error: " + ex);
                }
            }

            using (cnn = new MySqlConnection(connectionString))
            {
                try
                {
                    //Open connection
                    cnn.Open();
                    Console.WriteLine("Connection Open ! ");

                    Console.WriteLine("Executing failing transaction");
                    //In here we execute our sql commands
                    ExecuteSqlCommandsFail(cnn);

                    cnn.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Can not open connection! Error: " + ex);
                }
            }



            //Confirmation on closing app
            Console.WriteLine("Closing App");
            Console.ReadKey();
        }

        private static void ExecuteSqlCommands(MySqlConnection cnn)
        {
            MySqlTransaction transaction = cnn.BeginTransaction();

            try
            {
                //Allows us to enter sqlCommands
                //Insert into Player_Character
                var charSql = "insert into player_character (user_account_id, nickname, max_health, current_health, max_mana, current_mana, attack, defence, player_level) values (@user_account_id, @nickname, @max_health, @current_health, @max_mana, @current_mana, @attack, @defence, @player_level)";
                using var charCmd = new MySqlCommand(charSql, cnn, transaction);
                {
                    //Typesafe way to send SQL commands to the database 
                    charCmd.Parameters.AddWithValue("@user_account_id", "Gamer24/7");
                    charCmd.Parameters.AddWithValue("@nickname", "Cat smasher");
                    charCmd.Parameters.AddWithValue("@max_health", 500);
                    charCmd.Parameters.AddWithValue("@current_health", 500);
                    charCmd.Parameters.AddWithValue("@max_mana", 200);
                    charCmd.Parameters.AddWithValue("@current_mana", 200);
                    charCmd.Parameters.AddWithValue("@attack", 30);
                    charCmd.Parameters.AddWithValue("@defence", 50);
                    charCmd.Parameters.AddWithValue("@player_level", 0);
                    charCmd.Prepare();
                    charCmd.ExecuteNonQuery();
                }

                //Insert into Stats
                var statsSql = "insert into stats (player_id, kills, heals, damage) values ((SELECT LAST_INSERT_ID()), @kills, @heals, @damage)";
                using var statsCmd = new MySqlCommand(statsSql, cnn, transaction);
                {
                    //Typesafe way to send SQL commands to the database 
                    statsCmd.Parameters.AddWithValue("@kills", 0);
                    statsCmd.Parameters.AddWithValue("@heals", 0);
                    statsCmd.Parameters.AddWithValue("@damage", 0);
                    statsCmd.Prepare();
                    statsCmd.ExecuteNonQuery();
                }

                transaction.Commit();
                Console.WriteLine("Transaction Committed ");
                Console.WriteLine("");
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Console.WriteLine("Transaction failed.  Rolling back Error: " + ex);
            }
        }

        private static void ExecuteSqlCommandsFail(MySqlConnection cnn)
        {
            MySqlTransaction transaction = cnn.BeginTransaction();

            try
            {
                //Allows us to enter sqlCommands
                //Insert into Player_Character
                var charSql = "insert into player_character (user_account_id, nickname, max_health, current_health, max_mana, current_mana, attack, defence, player_level) values (@user_account_id, @nickname, @max_health, @current_health, @max_mana, @current_mana, @attack, @defence, @player_level)";
                using var charCmd = new MySqlCommand(charSql, cnn, transaction);
                {
                    //Typesafe way to send SQL commands to the database 
                    charCmd.Parameters.AddWithValue("@user_account_id", "Gamer24/7");
                    charCmd.Parameters.AddWithValue("@nickname", "Cat smasher2");
                    charCmd.Parameters.AddWithValue("@max_health", 500);
                    charCmd.Parameters.AddWithValue("@current_health", 500);
                    charCmd.Parameters.AddWithValue("@max_mana", 200);
                    charCmd.Parameters.AddWithValue("@current_mana", 200);
                    charCmd.Parameters.AddWithValue("@attack", 30);
                    charCmd.Parameters.AddWithValue("@defence", 50);
                    charCmd.Parameters.AddWithValue("@player_level", 0);
                    charCmd.Prepare();
                    charCmd.ExecuteNonQuery();
                }

                //Insert into Stats
                var statsSql = "insert into stats (player_id, kills, heals, damage) values ((SELECT LAST_INSERT_ID()), @kills, @heals, @damage) ";
                using var statsCmd = new MySqlCommand(statsSql, cnn, transaction);
                {
                    //Typesafe way to send SQL commands to the database 
                    statsCmd.Parameters.AddWithValue("@kills", null);
                    statsCmd.Parameters.AddWithValue("@heals", 0);
                    statsCmd.Parameters.AddWithValue("@damage", 0);
                    statsCmd.Prepare();
                    statsCmd.ExecuteNonQuery();
                }

                transaction.Commit();
                Console.WriteLine("Transaction Committed");
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Console.WriteLine("Transaction failed. Rolling back.");
                Console.WriteLine("Error message: " + ex);
            }
        }
    }
}
