
/*
trigger
 */
 use battle_game;
 
DELIMITER //
DROP PROCEDURE IF EXISTS level_up //
CREATE PROCEDURE level_up(IN player_id int, in player_level int)
BEGIN
    insert into player_skill (player_id, skill_id) values
    (player_id, (Select id from skill as s where player_level = s.level_req));
    -- Write your MySQL code to perform when a `table` row is inserted or updated here

END//
DELIMITER ;

create trigger trigger_level_update after update on player_character for each row 
call level_up (new.id, new.player_level);

create trigger trigger_level_insert after insert on player_character for each row 
call level_up (new.id, new.player_level);
 
 /* create a player to activate trigger
insert into player_character (user_account_id, nickname, max_health, current_health, max_mana, current_mana, attack, defence, player_level)
values("Gamer24/7", "hamsterG", 500, 500, 200, 200, 30, 50, 5);
*/